const formStart = document.forms.formulaireDemarrer;
formStart.addEventListener('submit', function (event) {
    event.preventDefault();
});

const formAnswer = document.forms.formulaireQuiz;
formAnswer.addEventListener('submit', function (event) {
    event.preventDefault();
});


let pointsScore = 0;
let errorsScore = 0;
// number of question 1-10
let qtyQuestions = 0;
// the user cant make mor errors then MaxErrors
let MaxErrors = 0;
let questionsToShow = [];
let answerToValidate = [];
//set first quesion
let currentQuestionOrder = 0;

let currentQuestion = "Scanning question...";
//  let formStart = document.getElementById('formulaireDemarrer');
//  let formAnswer= document.getElementById('formulaireQuiz');

formAnswer.querySelector('#question').textContent = currentQuestion;

// start Quiz
function startQuiz() {
    //set qty question
    qtyQuestions = formStart['nbQuestions'].value;
    //set MAX ERRORS
    MaxErrors = formStart['nbMaxErreurs'].value;

    //GET QUESTION
    questionsToShow = getQuestions(qtyQuestions)
    // DISPLAY QUESTION
    DisplayQuestion(questionsToShow[currentQuestionOrder]);
}

function getQuestions(qtyQuestions) {
    let sortedQuestions = [];
    let indexToSort = 0;
    while (sortedQuestions.length <= qtyQuestions) {
        indexToSort = Math.floor(Math.random() * questions.length);
        sortedQuestions.push(questions[indexToSort][0]);
        answerToValidate.push(questions[indexToSort][1]);
    }
    console.log(sortedQuestions);
    return sortedQuestions;
}

function DisplayQuestion(currentQuestion) {
        formAnswer.querySelector('#question').textContent = "Quelle est la capitale de " + currentQuestion + " ? (" + answerToValidate[currentQuestionOrder];
}

function validateAnswer() {
    if (formAnswer['reponse'].value == answerToValidate[currentQuestionOrder]) {
        addPoints();
    } else {
        addError();
    }
    // alert(currentQuestionOrder);
    NextQuestion(currentQuestionOrder);
}

function NextQuestion(currentQuestion) {
    if (currentQuestion == qtyQuestions-1) {
        formAnswer.querySelector('#question').textContent = 'you succed';
    }else{
        DisplayQuestion(questionsToShow[currentQuestionOrder++]);
    }
    ClearQuizForm();
}

function addError() {
    errorsScore++;
    if (errorsScore == MaxErrors) {
        formAnswer.querySelector('#question').textContent = 'you failed';
    }
}

function addPoints() {
    pointsScore++;
    document.querySelector('#pointage').textContent = pointsScore;
}

function ClearQuizForm(){
    formAnswer['reponse'].value = "" 
}


