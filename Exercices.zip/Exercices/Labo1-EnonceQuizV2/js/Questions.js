var questions = [
    {0: "Colombie-Britannique", 1: "Victoria" },
    {0:"Alberta", 1: "Edmonton"},
    {0:"Saskatchewan", 1: "Regina"},
    {0:"Manitoba", 1: "Winnipeg"},
    {0:"Ontario", 1: "Toronto"},
    {0:"Québec", 1: "Québec"},
    {0:"Terre-Neuve-et-Labrador", 1: "St. John's"},
    {0:"Nouveau-Brunswick", 1: "Fredericton"},
    {0:"Nouvelle-Écosse", 1: "Halifax"},
    {0:"Île-du-Prince-Édouard", 1: "Charlottetown"},
    {0:"Nunavut", 1: "Iqaluit"},
    {0:"Territoires du Nord-Ouest", 1: "Yellowknife"},
    {0:"Yukon", 1: "Whitehorse"}    
]





