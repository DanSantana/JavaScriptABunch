function RandomChar(quantité) {
   
   if (quantité === undefined) {    
      //Obtenir une valeur entière entre 97 et 122
      var charNombre = Math.floor((Math.random() * 26) + 97);
      return String.fromCharCode(charNombre);
   }
   else {
      var charNombres = [];
      for (var i=0; i<quantité; i++) {
         charNombres[i] = String.fromCharCode(Math.floor((Math.random() * 26) + 97));
      }
      return charNombres;
   }
}

function RandomIntVector(quantité, min, max) {
   
   if (quantité === undefined || quantité < 2) { 

      return Math.floor((Math.random() * max) + min);
   }
   else {
      
      var retour= [];
      
      for (var i=0; i<quantité; i++) {
         retour[i] = Math.floor((Math.random() * max) + min);
      }
      
      return retour;
   }
}

function RandomIntMatrice(nbLignes, nbColonnes, min, max) {
   var tab2D = [];
   
   for (var i=0; i<nbLignes; i++) {
      tab2D[i] = RandomIntVector(nbColonnes, min, max);
   }
   
   return tab2D;
}
