var Questions = [
{
    category : "Capitales",
    description : "Province/Territoire vs Capitale",
    questionList : {
        0: "Colombie-Britannique", 
        1: "Alberta", 
        2: "Saskatchewan",
        3: "Manitoba",
        4: "Ontario",
        5: "Québec",
        6: "Terre-Neuve-et-Labrador",
        7: "Nouveau-Brunswick",
        8: "Nouvelle-Écosse",
        9: "Île-du-Prince-Édouard",
        10 : "Nunavut",
        11: "Territoires du Nord-Ouest",
        12: "Yukon"
    },
    answerList : {
        0: "Victoria", 
        1: "Edmonton", 
        2: "Regina",
        3: "Winnipeg",
        4: "Toronto",
        5: "Québec",
        6: "St. John's",
        7: "Fredericton",
        8: "Halifax",
        9: "Charlottetown",
        10: "Iqaluit",
        11: "Yellowknife",
        12: "Whitehorse"
    }
},
{
    category : "base",
    questionList : {
        0: "cor", 1: "masculino"
    },
    answerList : {
        0 : "vermelho",
        1 : "masculino"
    }
},]